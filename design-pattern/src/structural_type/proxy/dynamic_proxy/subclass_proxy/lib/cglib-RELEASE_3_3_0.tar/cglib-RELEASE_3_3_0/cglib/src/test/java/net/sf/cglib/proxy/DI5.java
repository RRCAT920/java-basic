package net.sf.cglib.proxy;

interface DI5 {
    public int vararg(String... strs);
}
