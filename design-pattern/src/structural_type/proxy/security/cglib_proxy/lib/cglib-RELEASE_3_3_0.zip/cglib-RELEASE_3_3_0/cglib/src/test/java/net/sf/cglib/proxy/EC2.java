package net.sf.cglib.proxy;

public class EC2 extends EB {
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}

