package net.sf.cglib.proxy;

class D2 implements DI2 {
    public String derby() {
        return "D2";
    }
}
